
$(document).ready(function () {
    $('ul li a').click(function () {
        $('li a').removeClass("active");
        $(this).addClass("active");
    });
});
const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('nav');
const closeNav = document.querySelector('.close-nav'); // Select the close button

if (menuToggle) {
    menuToggle.onclick = function () {
        nav.classList.toggle('active');
        menuToggle.classList.toggle('active');
    };
}

if (closeNav) {
    closeNav.onclick = function () {
        nav.classList.remove('active');
        menuToggle.classList.remove('active');
    };
}
function startCounting(elementId, start = 1, end = 1000, interval = 1000) {
    let current = start;

    const counterElement = document.getElementById(elementId);

    const intervalId = setInterval(() => {
        counterElement.textContent = current + " +";
        if (current >= end) {
            clearInterval(intervalId);
        } else {
            current++;
        }
    }, interval);
}

// Call the function for the four counters
startCounting('counter1', 1, 284, 50);
startCounting('counter2', 1, 190, 50);
